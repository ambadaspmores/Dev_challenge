"use strict";

var direction = "asc";
var sparkJson = [];
var table, available;
var interval = false;


function displayTable(parseMessage) {
    var midprice;
    table = document.getElementById("displayTable");
    var rows = table.getElementsByTagName("tr");
    var headerRows = rows[0].getElementsByTagName("th");
	var arr = [];
    for (var i = 0; i < headerRows.length - 1; i++) {
        arr.push(headerRows[i].id);
    }
    if (rows.length <= 1) {
        var row = table.insertRow(1);
        for (i = 0; i < arr.length; i++) {
            if (i == 0)
                row.insertCell(i).innerHTML = parseMessage[arr[i]];
            else
                row.insertCell(i).innerHTML = parseMessage[arr[i]].toFixed(4);
        }
        row.insertCell(arr.length).id = parseMessage[arr[0]];
        midprice = (parseMessage.bestBid + parseMessage.bestAsk) / 2;
        pushToSpark(parseMessage[arr[0]], midprice);
    } else {
        available = false;
        for (var i = 1; i < rows.length; i++) {
            var colValue = rows[i].getElementsByTagName("td");
            var tdValue = colValue[0];
            if (tdValue.innerHTML == parseMessage.name) {
                for (var j = 1; j < arr.length; j++) {
                    colValue[j].innerHTML = parseMessage[arr[j]].toFixed(4);
                }
                midprice = (parseMessage.bestBid + parseMessage.bestAsk) / 2;
                sparkJson.forEach(function(item) {
                    if (item.name == parseMessage[arr[0]]) {
                        if (item.values.length >= 10) {
                            item.values.shift();
                            item.values.push(midprice);
                        } else {
                            item.values.push(midprice);
                        }
                    }
                })
                available = true;
            }
        }
        if (!available) {
            row = table.insertRow(rows.length);
            for (i = 0; i < arr.length; i++) {
                if (i == 0)
                    row.insertCell(i).innerHTML = parseMessage[arr[i]];
                else
                    row.insertCell(i).innerHTML = parseMessage[arr[i]].toFixed(4);
            }
            row.insertCell(arr.length).id = parseMessage[arr[0]];
            midprice = (parseMessage.bestBid + parseMessage.bestAsk) / 2;
            pushToSpark(parseMessage[arr[0]], midprice);
        }
    }

    // Sorting.
    sortTable(3, direction);

    if (!interval) {
        setInterval(drawGraph, 30000);
        interval = true;
    }

}

function pushToSpark(name, midprice) {
    var jsonObj = {};
    jsonObj.name = name;
    jsonObj.values = [midprice];
    sparkJson.push(jsonObj);
}

// Draw Graph
function drawGraph() {
    sparkJson.forEach(function(item) {
        const sparkItem = document.getElementById(item.name);
        Sparkline.draw(sparkItem, item.values);
    })
}


function onClickSort() {
    direction == "asc" ? direction = "desc" : direction = "asc";
}

function sortTable(n, dire) {
    var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
    table = document.getElementById("displayTable");
    switching = true;
    (dire != undefined && direction == "asc") ? dir = dire: dir = direction;
    direction = dir;
    while (switching) {
        switching = false;
        rows = table.getElementsByTagName("tr");
        for (i = 1; i < (rows.length - 1); i++) {
            shouldSwitch = false;
            x = rows[i].getElementsByTagName("td")[n];
            y = rows[i + 1].getElementsByTagName("td")[n];
            if (dir == "asc") {
                if (parseFloat(x.innerHTML) > parseFloat(y.innerHTML)) {
                    shouldSwitch = true;
                    break;
                }
            } else if (dir == "desc") {
                if (parseFloat(x.innerHTML) < parseFloat(y.innerHTML)) {
                    shouldSwitch = true;
                    break;
                }
            }
        }
        if (shouldSwitch) {
            rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
            switching = true;
            switchcount++;
        }
    }
}

